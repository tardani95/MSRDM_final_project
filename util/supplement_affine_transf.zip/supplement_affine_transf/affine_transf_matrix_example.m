%% Example: Lowest Row in Transformation: Affine Rectification
%
% Supplement to first lecture (this has nothing to do with tutorial 2)
%
% The Example shows a usecase for the lowest row [v] of an affine 
% Transformation matrix: T = [[R, t]; v]
% Since we are dealing with pixels (2d) our homogenous coord. are 3d.
%
% A distorted image (parallel lines are no longer parallel) is 
% rectified by applying a affine transformation matrix. This restores
% parallelism in the transformed lines.
%
% First the 2D transformation matrix is build from four lines that are known
% to be parallel, then the transformation is applied to the homogeneous pixel
% coordinates [px, py, 1].
% 
% Finally the transformed pixels are renormalized to homogeneous
% coordinates (devide by last dim) and plotted.
%   
% Keywords: Affine image rectification

function affine_transf_matrix_example()

    close all;

    % read image
    I_org = imread('image.jpeg');
    I_org = rgb2gray(I_org);

    % show original
    fig1 = imshow(I_org);
    title('Original Image (distorted)') 
    impixelinfo(fig1)

    %% projective transformation

    % define the pixels coordinates of lines that should be parallel (if image
    % where undistored) and plot them
    x1 = [379; 1328];
    x2 = [1309; 1014];
    x3 = [810; 666];
    x4 = [138; 1163];
    
    % plot lines connecting vertices
    v = [x1 x2 x3 x4];
    hold on
    plot_lines(v);
    plot_points(v);
    hold off

    % convert to homogenous coordinates (add new dimension)
    v_hc = [v; ones(1, 4)];

    % Compute the lines between the four vertices, that should be parallel.
    % Note: in 2d projective geometry lines can also be represented as homogenous
    % coordinates: w'*x = b --> [w1,w2,b]
    % The line between two points is the cross product of start and end. 
    l1 = cross(v_hc(:,1), v_hc(:,2));   % l1 || l2
    l2 = cross(v_hc(:,4), v_hc(:,3));

    m1 = cross(v_hc(:,2), v_hc(:,3));	% m1 || m2
    m2 = cross(v_hc(:,1), v_hc(:,4));

    % Compute the intersection points of these lines, again cross product.
    x1_inf = cross(l1, l2);
    x2_inf = cross(m1, m2);

    % Compute the line through these two intersection points
    l_inf = cross(x1_inf, x2_inf);

    %% Build Transformation (Affine Projection)
    
    % Form the matrix that enables affine rectification
    % This process is called Affine Rectification
    P = [eye(2), [0 0]'; l_inf'/norm(l_inf)];

    disp('The transformation matrix is:')
    disp('-----------------------------')
    disp(P)
    disp('-----------------------------')

    %% Apply Transformation

    % apply P to vertices
    v_warped = P*v_hc;

    % Restore vertices to homogeneous coordinates (devide by last dimension)
    v_warped_hc = bsxfun(@rdivide, v_warped, v_warped(end,:));

    % Warp the image using matlab imwarp function
    warp =  projective2d(inv(P)');
    I_warp = imwarp(I_org, warp);

    % Show image in a new figure
    % Display img rotated for better visualization.
    figure
    fig2 = imshow(imrotate(I_warp, 180)); 
    title('Image after projection (rotated, croped)') 
    impixelinfo(fig2)

    % Since we display the image rotated, we also need to rotate the
    % verices before plotting them.
    R = [cos(pi) -sin(pi) 0; sin(pi) cos(pi) 0; 0 0 1];
    v_warped_hc = R*v_warped_hc;
    
    % plot the transformed points
    hold on
    plot_lines(v_warped_hc);
    plot_points(v_warped_hc);
    hold off
    
    set(gca,'XLim',[200 2000])
    set(gca,'YLim',[400 3000])

end

function plot_lines(v)
    for i=1 : size(v,2)-1
        line([v(1,i), v(1,i+1)],[v(2,i), v(2,i+1)], 'Linewidth',4, 'Color', 'r')
    end
    line([v(1,end), v(1,1)],[v(2,end), v(2,1)], 'Linewidth',4, 'Color', 'r')
end

function plot_points(v)
    for i=1 : size(v,2)
        plot(v(1,i), v(2,i), 'ro', 'MarkerSize', 30, 'LineWidth', 2, 'Color', 'g');
    end
end


